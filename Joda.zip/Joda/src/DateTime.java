import static org.junit.Assert.*;

import org.joda.time.IllegalFieldValueException;
import org.joda.time.Interval;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;
import org.joda.time.Period;
import org.junit.Test;


public class DateTime {

	@Test
	public void criaDataValida() {
		//Fixture Setup
		//Exercise SUT
		LocalDateTime natal = new LocalDateTime(2017, 12, 25 ,12 ,30);
		  //Result Verification
		assertEquals(2017, natal.getYear());
		assertEquals(12, natal.getMonthOfYear());
		assertEquals(25, natal.getDayOfMonth());
		assertEquals(12, natal.getHourOfDay());
		assertEquals(30, natal.getMinuteOfHour());
		//Fixture Teardown
	}
	
	@Test(expected=IllegalFieldValueException.class)
	public void criaDataComMesNegativo() {
		//Fixture Setup
		//Exercise SUT
		LocalDateTime natal = new LocalDateTime(2017, -12, 25 ,12 ,30);
		//Result Verification
		//Fixture Teardown
	}
	
	@Test(expected=IllegalFieldValueException.class)
	public void criaDataComDiaNegativo() {
		//Fixture Setup
		//Exercise SUT
		LocalDateTime natal = new LocalDateTime(2017, 12, -25 ,12 ,30);
		//Result Verification
		//Fixture Teardown
	}
	
	@Test(expected=IllegalFieldValueException.class)
	public void criaDataComHorarioNegativo() {
		//Fixture Setup
		//Exercise SUT
		LocalDateTime natal = new LocalDateTime(2017, 12, 25 ,-12 ,30);
		//Result Verification
		//Fixture Teardown
	}
	
	@Test(expected=IllegalFieldValueException.class)
	public void criaDataComSegundosNegativo() {
		//Fixture Setup
		//Exercise SUT
		LocalDateTime natal = new LocalDateTime(2017, 12, 25 ,12 ,-30);
		//Result Verification
		//Fixture Teardown
	}
	
	@Test(expected=IllegalFieldValueException.class)
	public void criaDataCom60Segundos() {
		//Fixture Setup
		//Exercise SUT
		LocalDateTime natal = new LocalDateTime(2017, 12, 25 ,12 , 60);
		//Result Verification
		//Fixture Teardown
	}
	
	@Test(expected=IllegalFieldValueException.class)
	public void criaIntervalo() {
		//Fixture Setup
		LocalDateTime inicio = new LocalDateTime(2017, 12, 1, 12, 10);
		LocalDateTime fim = new LocalDateTime(2018, 12, 1, 13, 0);
		//Exercise SUT
		//Interval interval = new Interval(inicio, fim);
		//Result Verification

		//Fixture Teardown
	}
	
	@Test(expected=IllegalFieldValueException.class)
	public void criaPeriodo() {
		//Fixture Setup
		Period inicio = new Period(12, 30, 0, 10);
		//Exercise SUT
		//Interval interval = new Interval(inicio, fim);
		//Result Verification

		//Fixture Teardown
	}

}
