package domain;

public enum DifficultyLevel {

	EASY, MEDIUM, HARD
	
}

