package test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import core.Funcionario;

public class FuncionarioTest {

	Funcionario funcionario;
	@Before
	public void setUp() throws Exception {
		funcionario = new Funcionario();
	}

	@Test
	public void testFuncionarioNotNull() {
		assertNotNull(funcionario);
	}

}
