package test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

import core.Empresa;
import core.Funcionario;
import core.Projeto;

public class EmpresaTest {

	private Empresa empresa;
	private Projeto projeto;
	
	@Before
	public void setUp() throws Exception {
		empresa = new Empresa();
		projeto = new Projeto();
	}

	@Test
	public void testEmpresaNotNull() {
		assertNotNull(empresa);
	}

	@Test
	public void testEmpresaTemFuncionarios(){
		ArrayList<Funcionario> funcionarios = empresa.getFuncionarios();
		assertNotNull(funcionarios);
	}
	
	@Test
	public void testEmpresaTemProjetos(){
		ArrayList<Projeto> projetos = empresa.getProjetos();
		assertNotNull(projetos);
	}
	
	@Test
	public void testCriarProjeto(){
		assertTrue(empresa.criarProjeto());
	}
	
}
