package test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import core.EstadoOcorrencia;
import core.Funcionario;
import core.Ocorrencia;
import core.PrioridadeOcorrencia;
import core.TipoOcorrencia;

public class OcorenciaTest {
	Ocorrencia ocorrencia;
	Ocorrencia ocorrenciaTarefaBaixaFechada;
	
	@Before
	public void setUp() throws Exception {
		ocorrencia = new Ocorrencia(new Funcionario());
		ocorrencia.setTipo(TipoOcorrencia.TAREFA);
		ocorrencia.setPrioridade(PrioridadeOcorrencia.BAIXA);
		ocorrencia.setEstado(EstadoOcorrencia.ABERTA);
		
		ocorrenciaTarefaBaixaFechada = new Ocorrencia(new Funcionario());
		ocorrenciaTarefaBaixaFechada.setTipo(TipoOcorrencia.TAREFA);
		ocorrenciaTarefaBaixaFechada.setPrioridade(PrioridadeOcorrencia.BAIXA);
		ocorrenciaTarefaBaixaFechada.setEstado(EstadoOcorrencia.FECHADA);
	}

	@Test
	public void testOcorrenciaNotNull() {
		assertNotNull(ocorrencia);
	}
	
	@Test
	public void testResponsavelPorOcorrenciaNotNull(){
		assertNotNull(ocorrencia.getResponsavel());
	}
	
	@Test
	public void testOcorrenciaNaoConcluida(){
		assertFalse(ocorrencia.isConcluida());
	}
	
	@Test
	public void testOcorrenciaConcluida(){
		assertTrue(ocorrenciaTarefaBaixaFechada.isConcluida());
	}
	
	@Test
	public void testOcorrenciaPossuiChaveUnica(){
		assertNotNull(ocorrencia.getChaveUnica());
	}
	
	@Test
	public void testTipoOcorrenciaTarefaTarefa(){
		assertEquals(TipoOcorrencia.TAREFA, ocorrencia.getTipoOcorrencia());
	}
	
	@Test
	public void testModificarPrioridadeParaAlta(){
		ocorrencia.setPrioridade(PrioridadeOcorrencia.ALTA);
		assertEquals(PrioridadeOcorrencia.ALTA, ocorrencia.getPrioridade());
	}
	
	@Test
	public void testModificarPrioridadeDeOcorrenciaFechada(){
		assertFalse(ocorrenciaTarefaBaixaFechada.setPrioridade(PrioridadeOcorrencia.ALTA));
	}

	@Test
	public void testModificarFuncionarioDeOcorrenciaFechada(){
		assertFalse(ocorrenciaTarefaBaixaFechada.setResponsavel(new Funcionario()));
	}
}
