package core;

public class Ocorrencia {
	String chaveUnica;
	TipoOcorrencia tipo;
	PrioridadeOcorrencia prioridade;
	EstadoOcorrencia estado;
	Funcionario responsavel;
	String resumo;
	
	public Ocorrencia(Funcionario responsavel){
		this.estado = EstadoOcorrencia.ABERTA;
		this.responsavel = responsavel;
	}
	
	public Object getResponsavel() {
		return true;
	}

	public boolean isConcluida() {
		if(estado == EstadoOcorrencia.ABERTA)
			return false;
		return true;
	}

	public Object getChaveUnica() {
		return "";
	}

	public TipoOcorrencia getTipoOcorrencia() {
		return tipo;
	}

	public void setTipo(TipoOcorrencia tipo) {
		this.tipo = tipo;
		
	}

	public boolean setPrioridade(PrioridadeOcorrencia prioridade) {
		if(this.estado == EstadoOcorrencia.ABERTA){
			this.prioridade = prioridade;
			return true;
		}
		return false;
	}
	
	public boolean setResponsavel(Funcionario funcionario){
		if(this.estado == EstadoOcorrencia.ABERTA){
			this.responsavel = funcionario;
			return true;
		}
		return false;	
	}

	public PrioridadeOcorrencia getPrioridade() {
		return prioridade;
	}

	public void setEstado(EstadoOcorrencia estado) {
		this.estado = estado;
		
	}

	public EstadoOcorrencia getEstado() {
		return this.estado;
	}

}
