package core;

import java.util.ArrayList;

public class Funcionario {
	private ArrayList<Ocorrencia> ocorrencias;
	
	public Funcionario(){
		ocorrencias = new ArrayList<Ocorrencia>();
	}

	public void addOcorrencia(Ocorrencia ocorrencia) {
		this.ocorrencias.add(ocorrencia);
	}

	public ArrayList<Ocorrencia> getOcorrencias() {
		return ocorrencias;
	}
}
