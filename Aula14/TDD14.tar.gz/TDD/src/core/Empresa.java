package core;

import java.util.ArrayList;

public class Empresa {
	ArrayList<Funcionario> funcionarios;
	ArrayList<Projeto> projetos;
	
	public Empresa(){
		funcionarios = new ArrayList<Funcionario>();
		projetos = new ArrayList<Projeto>();
	}

	public ArrayList<Funcionario> getFuncionarios() {
		return funcionarios;
	}
	
	public ArrayList<Projeto> getProjetos() {
		return projetos;
	}

	public boolean criaOcorrencia(Projeto projeto, Funcionario funcionario){
		return projeto.criarOcorrencia(funcionario);
	}

	public boolean criarProjeto() {
		Projeto projeto = new Projeto();
		projetos.add(projeto);
		return true;
	}
}
