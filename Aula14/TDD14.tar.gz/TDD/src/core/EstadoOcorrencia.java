package core;

public enum EstadoOcorrencia {
	ABERTA,
	FECHADA
}
