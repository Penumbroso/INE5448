package core;

public enum PrioridadeOcorrencia {
	ALTA,
	MEDIA,
	BAIXA
}
