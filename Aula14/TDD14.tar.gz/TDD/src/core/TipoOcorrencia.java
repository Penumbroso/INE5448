package core;

public enum TipoOcorrencia {
	TAREFA,
	BUG,
	MELHORIA
}
