State COVerage Analysis
